export const BASE_URL = import.meta.env.VITE_REACT_APP_API_URL
export const BASE_KEY = import.meta.env.VITE_REACT_APP_API_KEY